DROP TABLE IF EXISTS `#__ccm_cms`;

